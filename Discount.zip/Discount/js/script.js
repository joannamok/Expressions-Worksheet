// Discount
var orgPrice = 55;
var item = "earrings"
var discount = orgPrice * .25;
var discountPrice = orgPrice - discount;
var tax = .08 * discountPrice;
var withTax = discountPrice + tax;

console.log("Your"+" "+ item +" "+ "was originally" +" " +orgPrice+" "+ "but after a "+ discount + " " + "discount it is now"+" "+discountPrice+" "+"without tax,and"+" "+withTax+" "+"with tax.");
