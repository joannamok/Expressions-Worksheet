// Dog Years

var humanYears = 12; // Age in human Years
var dogYears = 7; // Find the Age of Sparky by mult. by 7
var ageInDogYears = dogYears * humanYears; // Result Variable 84
//console.log(ageInDogYears); // 

console.log("Sparky is" + " " + humanYears +" "+ "in human years which is" +" "+ ageInDogYears +" "+ "in dog years.");
