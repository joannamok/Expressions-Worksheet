// Slice of Pie Part 1

var slices = 8; // amount of slices per pizza
var numStudents = 23; // number of student at party
var pizzas = 15; // number of pizzas ordered
var slicesPerStudent= slices * pizzas/numStudents; // Result Variable
//console.log(slicesPerStudent); // Results Printable 

console.log("Each person ate"+" "+slicesPerStudent+" "+"slices of pizza at the party");

