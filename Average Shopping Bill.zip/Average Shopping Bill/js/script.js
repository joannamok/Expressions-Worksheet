// Average Shopping Bill
var week1 = 253.67;
var week2 = 100.02;
var week3 = 256.89;
var week4 = 86.53;
var week5 = 120.23; // weekly totals of grocer bills for 5 weeks

var total= week1 + week2 + week3 + week4 + week5 //total spent

var average = (week1 + week2 + week3 + week4 + week5)/5; // average of weeklu bills

console.log("You have spent a total of" +" "+ total +" "+"on goceries over 5 weeks.That is an average of" +" "+ average + " "+"per week.");