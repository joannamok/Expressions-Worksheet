// Slice of Pie Part 2

var remainder = 23 % 4; // number of students given 4 slices each
//console.log(remainder); // Results Printable , remainder 3 

console.log("Sparky got"+" "+remainder+" "+"slices of pizza.");
